/**
 * Where the onboarding videos are served from. The test copy of this repo
 * does not include the 300MB of course videos, so by default it plays them
 * from the live site. Set VITE_MEDIA_BASE to '' to serve them from this site's
 * own /course-media folder instead, as the live repo does.
 */
const env = (import.meta as unknown as { env: Record<string, string | undefined> }).env
export const MEDIA_BASE: string = env.VITE_MEDIA_BASE ?? 'https://theaiagencyai.netlify.app'

export function media(path: string): string {
  return path ? `${MEDIA_BASE}${path}` : path
}
