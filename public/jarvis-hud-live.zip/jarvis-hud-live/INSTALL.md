# Install the Jarvis dashboard (exact source)

This zip is the exact Jarvis dashboard. Your Base44 builder installs it as-is. It does not design anything and it does not need to invent anything.

## What you do

1. In Base44, create a new app. On the home screen paste: `Create an app named Jarvis HUD with one blank Home page.` Wait for it to finish.
2. Open the new app. In the builder chat, click the paperclip, attach this zip, and paste the prompt below into the same message. Send it.
3. When the builder says it is done, click Dashboard at the top, then Secrets, then Add Secret. Add `HUD_KEY` (a long random password you invent, keep a copy) and `JARVIS_NATIVE_TOKEN` (the access token from your Jarvis agent, Agent settings, then Developer). If you chose Retell Jarvis, also add `RETELL_API_KEY`.
4. Click Publish, then Publish again in the window that opens. Secrets do nothing until you publish.
5. Open the published app, sign in, click SETTINGS, fill in Your Jarvis agent (agent ID, your name, Telegram link), then pick how Jarvis calls you.

## The prompt to paste with the zip

```text
Install the attached Jarvis dashboard package into this app as the exact source of truth. Unzip it and copy every file under source/ into this project at the same paths, replacing what is there.

Copy in this order, because a file that is imported must exist before the file that imports it: first everything under base44/, then src/api/, src/lib/, src/hooks/, src/utils/, then src/components/ (all of it, including src/components/jarvis/), then src/pages/, then src/index.css, and only last src/App.jsx, src/main.jsx and index.html. After every file is copied, restart or reload the dev server before building, so it cannot keep a cached file-not-found result from before the copy.

Never rename a file, never move a file to a different path, and never change an import path to work around a "Failed to resolve import" error. If you hit one: list the file it cannot find and prove whether it exists at that exact path; if it exists, the resolve result is stale, so re-write that file and its importer in place with identical content and build again. Renaming forks this app from the package and breaks every future update.

Keep the app's login requirement on. Do not redesign, simplify, rename or recreate any page, component, style, entity, backend function, shared module or workflow; use the files exactly as supplied. Keep secrets empty; I will add them myself in Dashboard, then Secrets. After copying, run the build and fix only genuine build errors caused by missing dependencies in package.json, nothing else. Then list every file you wrote and confirm the build passes. Do not publish; I will.
```

## If something is wrong

- The builder starts describing a design: stop it and resend the prompt. It must copy files, not design.
- Build error about a missing package: let it add the dependency, nothing more.
- Blank preview, or "Failed to resolve import" naming a file that is there: the file lookup went stale during the copy. Paste this: `The file it cannot resolve does exist. Do not rename anything and do not change any import path. List that file and its importer to prove both exist, restart or reload the dev server, then re-write both files in place with identical content and build again.` If your builder renames files instead, stop it and tell it to put the original names back.
- Nothing shows after publish: check Secrets were added, then Publish again.
