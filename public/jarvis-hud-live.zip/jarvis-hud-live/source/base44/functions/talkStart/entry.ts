import { createClientFromRequest } from 'npm:@base44/sdk@0.8.49';
import { secrets } from 'base44:runtime';
import { buildRevenueLines } from '../../shared/call-context.ts';

// Talk mode, Retell path. Creates a Retell web call for the owner's own Jarvis
// voice agent and returns the short lived access token the browser needs to
// join it. No phone number is used. The call ends up at retellWebhook like any
// other call from this agent, so the after-call bridge still runs agreed tasks.
const RETELL_URL = 'https://api.retellai.com/v2/create-web-call';

function json(body, status) {
  return Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
}

function buildContextSummary(profile, tasks, revenueLines) {
  const doing = tasks.filter((t) => t.status === 'doing').map((t) => t.title).filter(Boolean).slice(0, 5);
  const waiting = tasks.filter((t) => t.status === 'todo').map((t) => t.title).filter(Boolean).slice(0, 5);
  const lines = ['The owner opened a live voice chat from the dashboard. This is not a phone call. They want to talk, so keep turns short and let them lead.'];
  if (profile?.goal_90_day) lines.push('goal: ' + profile.goal_90_day);
  lines.push('doing: ' + (doing.length ? doing.join('; ') : 'nothing in progress'));
  lines.push('waiting: ' + (waiting.length ? waiting.join('; ') : 'nothing waiting'));
  if (revenueLines) lines.push(revenueLines);
  return lines.join('\n');
}

export default async function(req) {
  try {
    if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);

    let base44, user;
    try {
      base44 = createClientFromRequest(req);
      user = await base44.auth.me();
    } catch { return json({ error: 'unauthorized' }, 401); }
    if (!user) return json({ error: 'unauthorized' }, 401);
    if (user.role !== 'admin') return json({ error: 'forbidden' }, 403);

    const apiKey = secrets.get('RETELL_API_KEY');
    if (typeof apiKey !== 'string' || !apiKey.trim()) {
      return json({ error: 'missing_secret', message: 'Retell is not set up yet. Open Settings and pick Retell Jarvis to finish setup.' }, 503);
    }

    const profile = (await base44.asServiceRole.entities.Profile.list('-updated_date', 1))[0];
    const agentId = typeof profile?.retell_agent_id === 'string' ? profile.retell_agent_id.trim() : '';
    if (!agentId) {
      return json({ error: 'missing_profile_field', message: 'Retell is not set up yet. Open Settings and pick Retell Jarvis to finish setup.' }, 400);
    }

    const tasks = await base44.asServiceRole.entities.Task.list('-updated_date', 500).catch(() => []);
    const revenueLines = await buildRevenueLines(base44.asServiceRole.entities.Lead).catch(() => '');
    const context_summary = buildContextSummary(profile, tasks || [], revenueLines);

    let response;
    try {
      response = await fetch(RETELL_URL, {
        method: 'POST',
        redirect: 'manual',
        signal: AbortSignal.timeout(15_000),
        headers: { Authorization: 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_id: agentId,
          retell_llm_dynamic_variables: { context_summary },
          metadata: { source: 'hud_talk' },
        }),
      });
    } catch {
      return json({ error: 'retell_unreachable', message: 'Could not reach Retell right now. Try again in a moment.' }, 502);
    }
    if (!response.ok) {
      return json({ error: 'retell_rejected', message: 'Retell could not start the voice chat. Try again, or check Retell in Settings.' }, 502);
    }

    let data = {};
    try { data = await response.json(); } catch { /* handled below */ }
    if (typeof data?.access_token !== 'string' || !data.access_token) {
      return json({ error: 'retell_no_token', message: 'Retell could not start the voice chat. Try again.' }, 502);
    }

    await base44.asServiceRole.entities.ActivityLog.create({
      type: 'note', task_title: 'Voice chat', message: 'Owner started a voice chat from the dashboard.',
    }).catch(() => {});

    // The access token is single use and expires about 30 seconds after creation.
    return json({ ok: true, provider: 'retell', access_token: data.access_token, call_id: data.call_id || '' }, 200);
  } catch {
    return json({ error: 'talk_failed', message: 'The voice chat could not be started. Try again.' }, 500);
  }
}
