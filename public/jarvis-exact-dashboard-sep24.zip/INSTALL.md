# Jarvis exact source handoff

This is a source handoff, not a tested fresh-account auto-installer. The visual and behavior must come from the supplied `source/` tree; do not redraw, reinterpret, simplify, or replace components with a design prompt.

## Facilitator sequence

1. Back up the student’s existing app/repository and record its current Base44 account/app configuration, `.env` files, data, routes and workflows. Preserve them; do not overwrite or merge blindly.
2. Run `configure.mjs` from this extracted package BEFORE copying its `source/` tree. Supply only the student's own non-secret IDs/name/bot URL. It substitutes three configuration-bearing files without changing the design. Example: `node configure.mjs --hud-app-id STUDENT_HUD_ID --superagent-id STUDENT_AGENT_ID --owner-name "Student Name" --telegram-url https://t.me/STUDENT_BOT --timezone Australia/Brisbane`. The IDs must be real 24-character Base44 IDs; omit the Telegram argument to leave its button disabled. Never pass a token or password.
3. Copy the configured `source/` tree faithfully into the student project, reviewing collisions first. Keep the exact `src/pages/Today.jsx` route at `/`, `src/components/jarvis/Reactor.jsx`, `Reactor.css`, `src/index.css`, `tailwind.config.js`, `src/components/`, `base44/`, and runtime configuration. Preserve the student's app binding and merge entity schemas rather than overwriting unrelated entities.
4. Configure the student’s own Base44 runtime app/environment values. Configure backend secrets only in the student’s server-side secret store. Do not copy reference data, tokens, keys, phone values or account credentials.
5. Verify the generated tree with the supplied `verify.mjs` and root hash manifest. Stop on any mismatch; do not “fix” differences by redesigning source.
6. Install the included `facilitator/setupJarvisControls/` as the temporary backend function `setupJarvisControls`. Follow `facilitator/BOOTSTRAP-REFERENCE.md` for initialization/enrollment semantics, not its older external generator command. The exact runtime source is already included here. Use `facilitator/after-call-workflow-DISABLED.json` as the five-minute workflow draft. Keep it disabled until secret, control rows, auth and timestamp checks pass. Brisbane-only call runtime. Remove the temporary bootstrap after verified setup.
7. Do not publish, place calls, enable outbound calling, or claim fresh-account proof in this handoff.

## Student builder upload prompt (copy exactly; one prompt)

```text
Use the supplied Jarvis source tree exactly as provided. Do not redraw, reinterpret, simplify, or replace the design. Preserve the existing student app’s account configuration, environment, data and workflows. Mount src/pages/Today.jsx at / and retain the exact Reactor.jsx, Reactor.css, index.css, tailwind config, components, Base44 entities/functions and runtime config. Use configure.mjs for student-owned non-secret IDs/name/channel values, then verify with verify.mjs and the root hash manifest. Do not publish or place calls.
```

## Boundaries

The exact source comes from the export, not from prose. This does not prove a fresh-account setup, native-route stability, voice quality, automatic EOD calls, Telegram delivery or production readiness. Retell is not part of this clone.

If the builder cannot inspect a ZIP, attach the included `DASHBOARD-SOURCE.txt` instead. It contains the actual source, not a design description. If the tool cannot access all files, STOP and report the limitation; never recreate missing code from memory or a screenshot. Build the copied project with `npm install` and `npm run build` in the target environment before publication; the source-only checks here do not replace that build.
