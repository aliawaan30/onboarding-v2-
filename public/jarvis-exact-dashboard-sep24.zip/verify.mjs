import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const manifest=JSON.parse(fs.readFileSync(path.join(root,'MANIFEST.json'),'utf8'));
const hash=s=>createHash('sha256').update(s).digest('hex');
let exact=0;
for(const item of manifest.files){
 const filename=path.join(root,'source',item.path);if(!fs.existsSync(filename))throw Error('Missing '+item.path);
 const source=fs.readFileSync(filename,'utf8');
 if(!item.account_configuration){if(hash(source)!==item.sha256)throw Error('Changed source '+item.path);exact++}
 if(/6a8a73a121ef691355f714c9|6aab5cd44fd7225657336376|b44_9ed4b58a1bf40923_bot/.test(source))throw Error('Reference account leaked into '+item.path);
 if(/(?:sk_live_|ghp_|xoxb-)[A-Za-z0-9_-]{15,}|eyJhbGci[A-Za-z0-9_.-]{30,}|-----BEGIN (?:RSA )?PRIVATE KEY-----/.test(source))throw Error('Possible secret '+item.path);
 if(/\.(?:jsx?|tsx?)$/.test(item.path))for(const m of source.matchAll(/(?:from\s*|import\s*)['"](@\/[^'"]+|\.{1,2}\/[^'"]+)['"]/g)){
  const target=m[1].split('?')[0];const base=target.startsWith('@/')?path.join(root,'source/src',target.slice(2)):path.resolve(path.dirname(filename),target);
  if(!['','.js','.jsx','.ts','.tsx','.css','/index.js','/index.jsx','/index.ts'].some(e=>fs.existsSync(base+e)))throw Error('Missing import '+item.path+' -> '+target);
 }
}
console.log(JSON.stringify({files:manifest.files.length,lockedFilesVerified:exact,accountFiles:manifest.files.filter(f=>f.account_configuration).map(f=>f.path),imports:'resolved',referenceAccounts:'absent',note:'Source integrity, not fresh-account deployment or call proof.'},null,2));
