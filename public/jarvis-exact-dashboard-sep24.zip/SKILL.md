---
name: jarvis-exact-dashboard
description: Install the supplied Jarvis dashboard source faithfully; do not generate or redesign the dashboard from prose.
---

# Exact Jarvis clone handoff skill

Use this skill only when installing the supplied exact source clone for a student. The source tree is authoritative. Do not invent replacement JSX, CSS, entities, backend functions, routes, workflow definitions or visual behavior from a description.

## Required order

1. Read `INSTALL.md` and inspect the entire supplied `source/` tree.
2. Back up the student app and preserve its account configuration, environment, data, workflows and existing integrations.
3. Prepare the source faithfully, including the complete `src/components/` tree, `src/pages/Today.jsx`, `src/components/jarvis/Reactor.jsx`, `Reactor.css`, `src/index.css`, `tailwind.config.js`, `vite.config.js`, `base44/` entities/functions/shared code, and runtime app configuration.
4. Run the supplied `configure.mjs` BEFORE copying the configured source into the target app, with explicit non-secret substitutions only:
   - `__STUDENT_HUD_APP_ID__`
   - `__STUDENT_SUPERAGENT_ID__`
   - `__STUDENT_TELEGRAM_URL__`
   - `__STUDENT_OWNER_NAME__`
5. Keep the student’s own Base44 environment/app configuration. Backend secrets belong only in the student’s server-side secret store; never render or log them.
6. Run the supplied `verify.mjs` and compare the root hash manifest. Any mismatch is a stop condition.
7. Treat the facilitator bootstrap and draft five-minute native after-call workflow as a separate, disabled setup. Enable only after its own auth, secret, control-row and timestamp checks. Call runtime is Australia/Brisbane only.

## Faithfulness rules

- Do not use a design prompt to recreate the page.
- Do not redraw the reactor or substitute another component library.
- Do not remove “unused” files, alter routes, normalize formatting, or refactor source before verification.
- Do not overwrite the student’s existing full schema map, data, `.env`, workflows or account configuration.
- Never copy reference account IDs, records, tokens, keys, phone numbers or bot URLs. `configure.mjs` is the only permitted non-secret substitution path.
- Do not add Retell or claim EOD automatic calls.

## Stop conditions

Stop and report the exact file/error if the source archive, `configure.mjs`, `verify.mjs` or root hash manifest is missing; if any substitution input is missing; if the student timezone is not Australia/Brisbane; if backup/preservation is unavailable; or if verification hashes differ. Do not reconstruct missing source from prose.

## Handoff status

This process produces a source/configuration handoff. It does not publish, place a call, enable outbound calling, or establish fresh-account success. Any later live test must be separately recorded with student-owned evidence.
