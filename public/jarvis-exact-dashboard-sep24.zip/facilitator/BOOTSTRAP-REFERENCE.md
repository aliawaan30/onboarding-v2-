# Facilitator package generator (native-call pilot)

This directory generates a student-specific source bundle from the reviewed local HUD/native-call snapshots. It does **not** deploy, publish, create credentials, create a Superagent, or prove fresh-account setup. The native route is an observed internal Base44 route with no stability guarantee. Retell is intentionally excluded.

Run the local bootstrap mocks before handing off:

```sh
node student-jarvis-pilot/facilitator-package/test-setupJarvisControls.mjs
```

The mocks do not call Base44, a phone service or the network.

## Generate a bundle

From the course workspace:

```sh
node student-jarvis-pilot/facilitator-package/generate.mjs \
  --hud-app-id <student-HUD-app-id> \
  --superagent-id <student-Superagent-id> \
  --owner-name "Student name" \
  --timezone Australia/Brisbane \
  --out /private/tmp/jarvis-student-bundle
```

All five inputs are required. IDs must be Base44 24-character lowercase hex IDs. This reviewed package is deliberately restricted to `Australia/Brisbane`: the current verified helper uses Brisbane-specific UTC+10 date arithmetic, so another timezone is a blocker rather than a string substitution. The generator fails before writing if an input is missing or invalid. It never accepts or emits a token, phone number, existing record, or reference account ID.

## Manual setup (facilitator, per student)

1. Log into Base44 with the student’s account and confirm the app is private/login-required. Do not invite the student to the reference HUD.
2. Review the generated entity/function files against the student app. **Merge missing fields and entities; never overwrite the student’s existing full entity schema map.** Preserve existing business logic, RLS, Telegram handlers and workflows. Resolve any schema conflict manually and record it.
3. Install the generated backend functions, shared bridge, and `HeaderActions.jsx` in the student HUD app. Replace `__STUDENT_TELEGRAM_URL__` only with the student’s own approved channel or remove that button; never copy a reference bot URL. Confirm owner/admin authentication and service-role writes before enabling any call control. The bundle is source, not a deployment or permission grant.
4. Install the temporary `setupJarvisControls` backend function and invoke it only from an authenticated admin session. Its `initialize` action requires `confirm: INITIALIZE_JARVIS_CONTROLS`, creates only missing rows, never updates/deletes existing rows, reads before/after and fails closed on duplicates. It creates the two required singleton rows: (a) `owner_native_call` with `dispatch_state: idle` and `lock_until_ms: 0`; (b) `native_after_call_bridge` with `enabled: false`, `poll_lock_until_ms: 0`, and `native_naive_timestamps_utc: false`. Separate creates are not atomic; concurrent setup can still leave duplicates, which the function detects and blocks. Never create rows directly from the UI/client.
5. In the student HUD app’s server-side secrets, add `JARVIS_NATIVE_TOKEN` containing the student/Superagent-scoped token supplied through the approved Base44 credential flow. Never put it in prompts, frontend code, source control, logs or this bundle. If the token or scope is unavailable, stop with CALL ME disabled.
6. After manual UTC timestamp verification, invoke `setupJarvisControls` again with `action: enroll`, `confirm: ENROLL_JARVIS_AFTER_CALL_BRIDGE`, and `timestamp_policy_verified_utc: true`. It refuses enabled/already-enrolled bridges and any existing receipts; it sets the enrollment timestamp from the server clock and conditionally enables the bridge. This is not a history reset and does not reenroll blindly. **Remove/disable this temporary setup function after setup and record the test results.**
7. Review `workflow-template.json` in the student app’s current workflow UI. It is the exact sanitized DSL definition for an authenticated `afterCall` invocation every five minutes (`*/5 * * * *`, `Australia/Brisbane`), but is intentionally `status: draft` and `enabled: false`. Create no duplicate if an equivalent workflow exists. Enable only after the secret, both control rows, function auth and one controlled owner test are ready. Preserve existing workflows and do not use the legacy Automations API if the account’s current workflow UI offers the reviewed workflow mechanism. Confirm the function returns queued/202 and inspect `CallReceipt`; workflow completion alone is not execution proof.
7. Confirm the authenticated CALL ME button invokes `callMe`, the student’s control row is enabled only for the test, and `callStatus` reads only the student’s request. Make one owner-only test call; wait up to five minutes for pickup and 15 minutes total. Do not resend.
8. After the test, disable CALL ME if any auth, scope, transcript, duplicate, or execution check fails. Record exact errors and keep the student at partial/blocked readiness.

## Current-snapshot limitation

The generator now packages the exported current HUD entities/functions and reviewed native bridge runtime. It remains source plus manual instructions, not an installer: the facilitator must review schema merges, RLS, secret scope, workflow authentication and service-role bootstrap in the student app. Do not claim fresh-account proof or internal-route stability.

