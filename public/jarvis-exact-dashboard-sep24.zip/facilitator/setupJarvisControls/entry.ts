import { createClientFromRequest } from 'npm:@base44/sdk';
import { secrets } from 'base44:runtime';
import { handleSetup } from './setupJarvisControls.mjs';

export default async function(req: Request) {
  let base44;
  try { base44 = createClientFromRequest(req); } catch { return Response.json({ ok: false, error: 'unauthorized' }, { status: 401 }); }
  let token;
  try { token = secrets.get('JARVIS_NATIVE_TOKEN'); } catch { token = undefined; }
  return handleSetup(req, { base44, secretPresent: typeof token === 'string' && token.length > 0 });
}

