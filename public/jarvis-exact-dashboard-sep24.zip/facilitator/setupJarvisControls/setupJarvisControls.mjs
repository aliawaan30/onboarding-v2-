/* Temporary facilitator bootstrap core. Injects Base44 client, secret presence and clock for tests. */
const OWNER = 'owner_native_call';
const BRIDGE = 'native_after_call_bridge';
const json = (body, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });

async function bodyOf(req) {
  const type = req.headers?.get?.('content-type') || '';
  if (!type.toLowerCase().startsWith('application/json')) return { error: 'json_content_type_required' };
  try {
    const raw = await req.text();
    if (new TextEncoder().encode(raw).byteLength > 4096) return { error: 'body_too_large' };
    const value = JSON.parse(raw);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return { error: 'json_object_required' };
    return value;
  } catch { return { error: 'invalid_json' }; }
}

async function admin(base44) {
  try {
    const user = await base44.auth.me();
    return user?.role === 'admin';
  } catch { return false; }
}

async function rows(entity, query) { return entity.filter(query, '-created_date', 100); }
function exactOne(list) { return Array.isArray(list) && list.length === 1; }

export async function handleSetupUnsafe(req, { base44, secretPresent, now = () => Date.now() }) {
  if (req.method !== 'POST') return json({ ok: false, error: 'method_not_allowed' }, 405);
  // Authentication and secret presence precede body/action processing.
  if (!(await admin(base44))) return json({ ok: false, error: 'forbidden' }, 403);
  if (!secretPresent) return json({ ok: false, error: 'native_token_not_configured' }, 503);
  const body = await bodyOf(req);
  if (body.error) return json({ ok: false, error: body.error }, 400);
  const controls = base44.asServiceRole.entities.CallControl;
  const receipts = base44.asServiceRole.entities.CallReceipt;
  const action = body.action;
  if (action === 'initialize') {
    if (body.confirm !== 'INITIALIZE_JARVIS_CONTROLS') return json({ ok: false, error: 'explicit_confirmation_required' }, 400);
    const beforeOwner = await rows(controls, { name: OWNER });
    const beforeBridge = await rows(controls, { name: BRIDGE });
    if (beforeOwner.length > 1 || beforeBridge.length > 1) return json({ ok: false, error: 'duplicate_control_rows' }, 409);
    if (!beforeOwner.length) await controls.create({ name: OWNER, dispatch_state: 'idle', lock_until_ms: 0 });
    if (!beforeBridge.length) await controls.create({ name: BRIDGE, enabled: false, poll_lock_until_ms: 0, native_naive_timestamps_utc: false });
    // No update or delete is ever attempted. Separate creates are intentionally not claimed atomic.
    const afterOwner = await rows(controls, { name: OWNER });
    const afterBridge = await rows(controls, { name: BRIDGE });
    if (!exactOne(afterOwner) || !exactOne(afterBridge)) return json({ ok: false, error: 'control_bootstrap_not_unique' }, 409);
    return json({ ok: true, action, owner_native_call: 'present', native_after_call_bridge: 'present', warning: 'separate creates are not atomic; duplicate detection is fail-closed' });
  }
  if (action === 'enroll') {
    if (body.confirm !== 'ENROLL_JARVIS_AFTER_CALL_BRIDGE' || body.timestamp_policy_verified_utc !== true) return json({ ok: false, error: 'explicit_utc_confirmation_required' }, 400);
    const bridges = await rows(controls, { name: BRIDGE });
    const owners = await rows(controls, { name: OWNER });
    if (!exactOne(bridges) || !exactOne(owners)) return json({ ok: false, error: 'controls_not_unique' }, 409);
    const bridge = bridges[0];
    if (bridge.enabled === true || bridge.enrollment_at_ms != null) return json({ ok: false, error: 'already_enrolled' }, 409);
    const existingReceipts = await rows(receipts, {});
    if (existingReceipts.length) return json({ ok: false, error: 'existing_call_receipts_require_review' }, 409);
    const enrollment = now();
    if (!Number.isSafeInteger(enrollment) || enrollment <= 0) return json({ ok: false, error: 'invalid_server_clock' }, 500);
    const result = await controls.updateMany(
      { id: bridge.id, name: BRIDGE, enabled: false, enrollment_at_ms: bridge.enrollment_at_ms ?? null },
      { $set: { enabled: true, enrollment_at_ms: enrollment, native_naive_timestamps_utc: true } },
    );
    if (!result?.success || result.updated !== 1) return json({ ok: false, error: 'enrollment_not_applied' }, 409);
    const after = await rows(controls, { name: BRIDGE });
    if (!exactOne(after) || after[0].enabled !== true || after[0].enrollment_at_ms !== enrollment) return json({ ok: false, error: 'enrollment_readback_failed' }, 409);
    return json({ ok: true, action, enrolled_at_ms: enrollment, timestamp_policy: 'verified UTC naive timestamps' });
  }
  return json({ ok: false, error: 'unknown_action' }, 400);
}

export async function handleSetup(req, deps) {
  try { return await handleSetupUnsafe(req, deps); }
  catch { return json({ ok: false, error: 'setup_backend_failure' }, 503); }
}

