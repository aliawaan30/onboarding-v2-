// Mechanical account substitutions only. Does not deploy, call, or handle secrets.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const arg=n=>{const i=process.argv.indexOf('--'+n);return i<0?undefined:process.argv[i+1]};
const values={__STUDENT_HUD_APP_ID__:arg('hud-app-id'),__STUDENT_SUPERAGENT_ID__:arg('superagent-id'),__STUDENT_OWNER_NAME__:arg('owner-name'),__STUDENT_TELEGRAM_URL__:arg('telegram-url')||''};
function fail(m){console.error(m);process.exit(1)}
for(const k of ['__STUDENT_HUD_APP_ID__','__STUDENT_SUPERAGENT_ID__'])if(!/^[a-f0-9]{24}$/.test(values[k]||''))fail('Supply both student Base44 IDs; no teacher IDs.');
if(!/^[\p{L}][\p{L} -]{0,79}$/u.test(values.__STUDENT_OWNER_NAME__||''))fail('Owner name must use letters, spaces or hyphens.');
if(values.__STUDENT_TELEGRAM_URL__&&!/^https:\/\/t\.me\/[A-Za-z0-9_]+$/.test(values.__STUDENT_TELEGRAM_URL__))fail('Telegram must be the student bot HTTPS t.me URL, or omitted.');
if(arg('timezone')!=='Australia/Brisbane')fail('This exact snapshot has Brisbane date arithmetic. Other timezones require separate tested changes.');
const files=['src/components/jarvis/HeaderActions.jsx','base44/functions/callMe/entry.ts','base44/shared/after-call-bridge.ts'];
const planned=files.map(p=>{const f=path.join(root,'source',p);let c=fs.readFileSync(f,'utf8');if(!c.includes('__STUDENT_'))fail('Already configured: use a fresh archive; refusing to guess old values.');for(const [k,v]of Object.entries(values))c=c.split(k).join(v);return[f,c]});
for(const[f,c]of planned)fs.writeFileSync(f,c);
console.log('Configured 3 account-specific source files. No deployment, secret changes or calls. Keep native calling disabled until facilitator checks pass.');
