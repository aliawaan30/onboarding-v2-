import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { base44 } from '@/api/base44Client';

const TG_URL = '__STUDENT_TELEGRAM_URL__';
const TG_READY = /^https:\/\/t\.me\/[A-Za-z0-9_]+$/.test(TG_URL);
const TOAST_MS = 5000;
const POLL_MS = 3000;
const MAX_POLL_MS = 180000;
const COOLDOWN_MS = 60000;
const btnBase = 'font-mono text-[10px] tracking-[0.18em] uppercase px-2.5 py-1.5 border border-hud-border bg-transparent text-hud-text2 hover:bg-hud-panel hover:text-hud-text transition-colors duration-200 focus:outline-none focus-visible:border-hud-accent inline-flex items-center gap-1.5 disabled:opacity-60';

function prefersReducedMotion() { return typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches; }
export function cooldownSeconds(deadlineMs, nowMs = Date.now()) {
  if (!Number.isFinite(deadlineMs) || deadlineMs <= nowMs) return 0;
  return Math.max(0, Math.ceil((deadlineMs - nowMs) / 1000));
}

export default function HeaderActions() {
  const { user } = useAuth();
  const [state, setState] = useState('idle');
  const [toast, setToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  const [toastRed, setToastRed] = useState(false);
  const pendingRef = useRef(false);
  const timer = useRef(null);
  const pollTimer = useRef(null);
  const mounted = useRef(true);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const [, refreshClock] = useState(() => Date.now());
  const cooldown = cooldownSeconds(cooldownUntil);
  const reduced = prefersReducedMotion();
  useEffect(() => { mounted.current = true; return () => { mounted.current = false; if (timer.current) clearTimeout(timer.current); if (pollTimer.current) clearTimeout(pollTimer.current); }; }, []);
  useEffect(() => {
    const refresh = () => refreshClock(Date.now());
    const id = setInterval(refresh, 1000);
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    return () => { clearInterval(id); document.removeEventListener('visibilitychange', refresh); window.removeEventListener('focus', refresh); };
  }, []);
  const showToast = (msg, red = false) => { if (!mounted.current) return; setToastMsg(msg); setToastRed(red); setToast(true); if (timer.current) clearTimeout(timer.current); timer.current = setTimeout(() => setToast(false), TOAST_MS); };
  const showUnknown = () => { if (!mounted.current) return; setState('unknown'); setCooldownUntil(Date.now() + 600_000); showToast('Request status unknown. Check Jarvis before retrying.', true); };
  const poll = async (requestId) => {
    const started = Date.now();
    while (Date.now() - started < MAX_POLL_MS) {
      await new Promise((resolve) => { pollTimer.current = setTimeout(resolve, POLL_MS); });
      if (!mounted.current) return;
      let response, data;
      try { response = await base44.functions.invoke('callStatus', { request_id: requestId }); data = response?.data; } catch (e) { response = e?.response; data = response?.data; }
      if (!mounted.current) return;
      if (data?.state === 'submitted') { setState('submitted'); setCooldownUntil(Date.now() + COOLDOWN_MS); showToast('Call request sent to Jarvis.'); return; }
      if (data?.state === 'failed') { setState('failed'); showToast('Call request was not accepted. Check the call service.', true); return; }
      if (data?.state === 'unknown' || response?.status === 409) { showUnknown(); return; }
      if (response?.status === 401) { setState('failed'); showToast('Sign in to check call status.', true); return; }
      if (response?.status === 403) { setState('failed'); showToast('Admin only.', true); return; }
      if (!response || response.status >= 400) { showUnknown(); return; }
      setState('preparing');
    }
    showUnknown();
  };
  const handleCallMe = async () => {
    if (pendingRef.current || cooldown > 0 || !mounted.current) return;
    pendingRef.current = true; setState('queued'); showToast('Requesting a call…');
    try {
      const response = await base44.functions.invoke('callMe', {});
      if (!mounted.current) return;
      const data = response?.data;
      if (response?.status !== 202 || !data?.request_id) { showUnknown(); return; }
      showToast('Call request queued. Jarvis is preparing your call.');
      await poll(data.request_id);
    } catch (e) {
      if (!mounted.current) return;
      const status = e?.response?.status;
      const known = ['native_token_not_configured', 'control_not_initialized', 'control_not_unique', 'call_control_unavailable'].includes(e?.response?.data?.error);
      if (status === 401 || status === 403 || status === 429 || known) {
        setState('failed');
        if (status === 429) setCooldownUntil(Date.now() + 60_000);
        showToast(status === 401 ? 'Sign in to call.' : status === 403 ? 'Admin only.' : status === 429 ? 'Cooldown active — wait a moment.' : 'Call service is unavailable. Check Jarvis settings.', true);
      } else showUnknown();
    }
    finally { pendingRef.current = false; }
  };
  const ownerLabel = user?.full_name ? user.full_name.trim().split(/\s+/)[0].toUpperCase() : 'OWNER';
  return <div className="relative ml-auto flex items-center gap-2">
    <span className="font-mono text-[10px] tracking-[0.18em] uppercase text-hud-faint px-1">{ownerLabel}</span>
    <button type="button" onClick={handleCallMe} disabled={pendingRef.current || state === 'queued' || state === 'preparing' || cooldown > 0} className={btnBase}>{state === 'queued' ? 'Requesting…' : state === 'preparing' ? 'Preparing…' : cooldown > 0 ? `Cooldown ${cooldown}s` : 'Call Me'}</button>
    <button type="button" disabled={!TG_READY} onClick={() => TG_READY && window.open(TG_URL, '_blank', 'noopener,noreferrer')} className={btnBase}>Text Jarvis</button>
    <div aria-live="polite" className="absolute right-0 top-full mt-2 z-50 pointer-events-none" style={{ opacity: toast ? 1 : 0, transform: toast ? 'translateY(0)' : 'translateY(-4px)', transition: reduced ? 'none' : 'opacity 200ms ease-out, transform 200ms ease-out' }}>
      {toast && <div className="max-w-[320px] font-mono text-[10px] tracking-[0.12em] bg-hud-panel border px-3 py-1.5 text-right" style={{ color: toastRed ? '#E5533D' : '#EAF4FF', borderColor: toastRed ? 'rgba(229,83,61,0.5)' : '#14356B' }}>{toastMsg}</div>}
    </div>
  </div>;
}

