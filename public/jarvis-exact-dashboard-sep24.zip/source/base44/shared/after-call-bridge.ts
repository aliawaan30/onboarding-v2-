/* After-call poller library; importing the module performs no remote side effects.
 * The store methods mirror Base44 entity methods; updateMany must be an atomic conditional
 * update and the caller must verify updated === 1.
 */

export const BREV_APP_ID = '__STUDENT_SUPERAGENT_ID__';
export const BASE = `https://app.base44.com/api/apps/${BREV_APP_ID}`;
export const CONTROL_NAME = 'native_after_call_bridge';
export const POLL_LOCK_MS = 300_000;
export const UNKNOWN_HOLD_MS = 600_000;
export const MAX_CANDIDATES_PER_POLL = 1;
export const MAX_SCAN_MS = 60_000;

export const TRANSCRIPT_PROMPT = [
  'DO NOT CALL ANYONE.',
  'This is the exact ENDED owner call identified by call ID {{CALL_ID}}, with platform status {{CALL_STATUS}}. Ended does not mean successful.',
  'Use the authenticated HUD backend functions for app __STUDENT_HUD_APP_ID__: call getContext, then save the owner task with upsertTask before executing it.',
  'Fetch the full exact transcript for this call ID with native tools. Apply CALL WRAP-UP AND EXECUTION v4 and execute safe authorized work end to end without requiring reconfirmation.',
  'LIVE BOARD PROGRESS v1: For every task you will actually execute, first call upsertTask with its stable title, status doing, execution_owner jarvis, and a short factual progress_note saying what you are starting. Wait for a successful save before starting the work. Do not leave executing work in todo. A queued task that has not started must stay todo. Tasks for the owner to perform must use execution_owner owner and remain open.',
  'At real milestones update that same title with a factual progress_note, keeping status doing. If work lasts several minutes, save another actual progress update when a tool returns; never invent progress percentages or fake heartbeats. Never send progress_updated_at; the server stamps it. If blocked, return status todo with a progress_note describing the specific blocker. Finish by storing the full usable deliverable and source URLs in notes (not merely a sandbox filename), then status done and progress_note Result saved. Preserve call ID in notes for deduplication. Do not repeat completed work to create activity.',
  'Check HUD call-ID records before every action; this dispatch receipt is not proof that execution completed. If this call ID already has a completed execution record, do not repeat safe tasks.',
  'Never treat voicemail, an agent suggestion, or an unconfirmed statement as owner authorization.',
  'The platform may mark a connected call failed even when useful owner speech exists. Read the actual timestamped transcript, not just its generated summary. Recover only clear requests in the owner speech; never invent missing words, infer an unfinished correction, or execute a summary suggestion. The latest clear correction wins. If a request is cut off or materially ambiguous, record the clarification needed without guessing.',
  'Use the call timestamp and Profile timezone to resolve today/this afternoon; preserve the original timing if recovery is delayed. If the owner asked for a task for THEM to contact someone, create that open task for the owner; do not contact that person or mark the contact done. Do not create chores from the assistant opening report. Ordinary discussion is not a task request.',
  'For research or ranking, follow the exact scope, count, geography and criteria the owner requested. Never invent Google longevity, rankings, or evidence; state unknown explicitly. Do not perform outreach or other irreversible contact.',
  'A search that finds no official website supports only No official website found in the checked sources, not proof that no website exists. Do not invent commercial claims, conversion guarantees, platform fees, customer ROI, or statements that directory reviews are invisible. In draft sales copy, use qualified, factual wording and placeholders for unverified claims.',
  'Do not stop at worker reports or a next-action proposal. Consolidate and save the requested deliverable. Resolve material evidence conflicts where possible; unresolved facts must be labeled unknown or unverified with lower confidence, not used to invent certainty or silently abandon the work. If a real permission or tool blocker prevents completion, record the specific blocker on the existing task.',
  'Use getContext, upsertTask, remember, logSession, and upsertLead as appropriate; save results to the HUD and verify each result.',
  'HUD PAYLOAD CONTRACT: Call the backend-function tool with app_id, function_name, and payload as an object. upsertLead requires business_name and suburb; use trade (not business_type), source_url (not source), phone, website, notes, status. Put the primary official source in source_url and additional sources in notes. Read back each saved Lead and verify its source_url, trade, phone and website, not just its existence. upsertTask requires title; put deliverables and call ID in notes. remember requires text (not content) and kind. logSession requires title: first create status open with job and conversation_ref, then close the same title with status done and outcome after the work is saved; notes is not a session field. Never mark the task complete before its required records and result fields have been saved and read back.',
  'If the call contains no actionable owner request, do not invent a task, lead, or follow-up from the opening report. An explicitly cancelled request must not execute. An assistant suggestion is not permission to call or contact anyone. Preferred call_hours are not an instruction to postpone safe work.',
  'Finish and verify the saved work before notification delivery. Use a connected Telegram sending tool or existing notification workflow if available. If this conversation has no direct Telegram tool, the verified one-time Telegram workflow path is allowed once for this call, addressed only to the registered owner; it must be one-shot, never recurring. Do not modify other workflows. Do not hold task completion open while waiting for that notification or repeatedly search conversations or sleep in a loop. Claim delivery only when independently confirmed; otherwise say queued or unavailable and record that limitation in the session outcome.',
  'Do not claim that a task was completed unless the HUD and the native execution output verify it.',
].join(' ');

const ID = /^[a-f0-9]{24}$/;

// Only speech attributed to the owner within the ended call counts. Platform
// callbacks can be serialized as user messages after hang-up; exclude them.
function hasOwnerSpeech(transcript, startedAt, endedAt, nativeUtc) {
  return transcript.some((entry) => {
    if (entry?.role !== 'user' || typeof entry.text !== 'string' || !entry.text.trim()) return false;
    if (/^\s*\[(?:Outbound|Inbound) call\]/i.test(entry.text)) return false;
    const at = isoMs(entry.at, nativeUtc);
    return Number.isFinite(at) && at >= startedAt && at <= endedAt;
  });
}

function isoMs(value, nativeNaiveTimestampsAreUtc = false) {
  if (typeof value !== 'string') return NaN;
  if (/[zZ]|[+-]\d\d:\d\d$/.test(value)) return Date.parse(value);
  // Opt-in only: native responses have been observed without a zone; callers
  // must configure this after verifying the platform's timestamp policy.
  if (nativeNaiveTimestampsAreUtc && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?$/.test(value)) return Date.parse(`${value}Z`);
  return NaN;
}

function responseJson(value, status = 200) {
  return Response.json(value, { status, headers: { 'Cache-Control': 'no-store' } });
}

async function request(fetchImpl, url, token, init = {}, timeoutMs = 15_000) {
  return fetchImpl(url, {
    ...init,
    redirect: 'manual',
    signal: AbortSignal.timeout(timeoutMs),
    headers: { Authorization: `Bearer ${token}`, ...(init.body ? { 'Content-Type': 'application/json' } : {}) },
  });
}

export async function findVisibleMessage(fetchImpl, token, conversationId, messageId) {
  if (!ID.test(conversationId) || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(messageId)) return false;
  try {
    const response = await fetchImpl(`${BASE}/user-agent/conversations/${conversationId}/messages?limit=200`, {
      method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(5_000), headers: { Authorization: `Bearer ${token}` },
    });
    if (!response.ok) return false;
    const data = await response.json();
    const messages = Array.isArray(data) ? data : data?.messages;
    return Array.isArray(messages) && messages.some((message) => message?.id === messageId && message?.role === 'user');
  } catch { return false; }
}

// A verified delivered message clears only the ambiguous dispatch state, not
// the cooldown. This never sends another message or places another call.
export async function reconcileCallDispatch(controls, fetchImpl, pat) {
  const rows = await controls.filter({ name: 'owner_native_call' }, '-created_date', 2);
  if (rows.length !== 1) return false;
  const row = rows[0];
  if (row.name !== 'owner_native_call' || !['unknown', 'submitting'].includes(row.dispatch_state)) return false;
  if (!await findVisibleMessage(fetchImpl, pat, row.conversation_id, row.message_id)) return false;
  const result = await controls.updateMany(
    { id: row.id, name: row.name, request_id: row.request_id, conversation_id: row.conversation_id, message_id: row.message_id, dispatch_state: row.dispatch_state },
    { $set: { dispatch_state: 'submitted' } },
  );
  return result?.success === true && result.updated === 1;
}

/** Confirm a slow native POST by observing the exact user message once it is visible.
 * No second POST is ever attempted. A visible exact UUID proves dispatch only, not execution. */
export async function postWithDeliveryConfirmation(fetchImpl, url, token, body, conversationId, messageId) {
  const monitorUrl = `${BASE}/user-agent/conversations/${conversationId}/messages?limit=20`;
  let stopped = false;
  let timer;
  const pause = (ms) => new Promise((resolve) => { timer = setTimeout(resolve, ms); });
  const postPromise = request(fetchImpl, url, token, { method: 'POST', body: JSON.stringify(body) }, 180_000);
  // Always observe rejection so a monitor win cannot create an unhandled rejection.
  postPromise.catch(() => {});
  const postOutcome = postPromise.then((response) => {
    if (response.ok) return { kind: 'accepted' };
    if (response.status >= 400 && response.status < 500 && response.status !== 408) return { kind: 'rejected', status: response.status };
    return { kind: 'unknown' };
  }, () => ({ kind: 'unknown' }));
  const monitor = (async () => {
    // Let an already-resolved POST win before starting any read monitor.
    await pause(1000);
    for (let attempt = 0; attempt < 3 && !stopped; attempt++) {
      if (attempt) await pause(1000);
      if (stopped) return { kind: 'cancelled' };
      try {
        const response = await fetchImpl(monitorUrl, {
          method: 'GET', redirect: 'manual', signal: AbortSignal.timeout(5_000),
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) {
          continue;
        }
        const data = await response.json();
        const messages = Array.isArray(data) ? data : data?.messages;
        if (Array.isArray(messages) && messages.some((message) => message?.id === messageId && message?.role === 'user')) return { kind: 'confirmed' };
      } catch { /* bounded read-only monitor; unresolved delivery remains ambiguous */ }
    }
    return { kind: 'unknown' };
  })();
  // A monitor timeout means only that the message is not visible yet. It must
  // not beat a still-running POST and manufacture an early `unknown` state.
  // Await the bounded POST outcome before declaring ambiguity; a confirmed
  // visible message remains an allowed early success path.
  const winner = await Promise.race([postOutcome, monitor]);
  if (winner.kind === 'unknown') {
    const outcome = await postOutcome;
    stopped = true;
    clearTimeout(timer);
    return outcome;
  }
  stopped = true;
  clearTimeout(timer);
  return winner;
}

/**
 * Run one read/dispatch pass. The caller supplies a Base44 service-role entity facade.
 * `pat` is the server-only JARVIS_NATIVE_TOKEN; it is never returned or logged.
 */
export async function runAfterCallPoll({ store, fetchImpl = fetch, pat, now = Date.now, enabled = true }) {
  if (!enabled || !pat) return { enabled: false, processed: 0, reason: 'disabled_or_missing_secret' };
  const controls = store.control;
  const receipts = store.receipt;
  const configured = await controls.filter({ name: CONTROL_NAME }, '-created_date', 2);
  if (configured.length !== 1 || configured[0].enabled !== true || !Number.isFinite(configured[0].enrollment_at_ms)) {
    return { enabled: false, processed: 0, reason: configured.length === 1 ? 'not_configured' : 'control_not_unique' };
  }
  const control = configured[0];
  const t = now();
  const scanDeadline = t + MAX_SCAN_MS;
  const requestId = crypto.randomUUID();
  const claim = await controls.updateMany(
    { id: control.id, name: CONTROL_NAME, poll_lock_until_ms: { $lte: t } },
    { $set: { poll_request_id: requestId, poll_lock_until_ms: t + POLL_LOCK_MS } },
  );
  if (!claim?.success || claim.updated !== 1) return { enabled: true, processed: 0, reason: 'poll_lock_busy' };

  try {
    await reconcileCallDispatch(controls, fetchImpl, pat);
    const auth = await request(fetchImpl, `${BASE}/auth/token`, pat);
    if (!auth.ok) return { enabled: true, processed: 0, reason: 'runtime_token_rejected' };
    const authData = await auth.json();
    const runtimeToken = typeof authData?.token === 'string' && authData.token ? authData.token : null;
    if (!runtimeToken) return { enabled: true, processed: 0, reason: 'runtime_token_missing' };
    const list = await request(fetchImpl, `${BASE}/phone/calls?limit=20&offset=0`, runtimeToken);
    if (!list.ok) return { enabled: true, processed: 0, reason: 'call_list_failed' };
    const calls = (await list.json())?.calls;
    if (!Array.isArray(calls)) return { enabled: true, processed: 0, reason: 'call_list_invalid' };
    let processed = 0;
    let candidates = 0;
    let reconciliations = 0;
    for (const call of calls) {
      if (now() >= scanDeadline) return { enabled: true, processed, reason: 'scan_deadline' };
      if (call?.is_owner !== true || !['completed', 'failed'].includes(call.status) || typeof call.id !== 'string' || !ID.test(call.id)) continue;
      const startedAt = isoMs(call.started_at, control.native_naive_timestamps_utc === true);
      const completedAt = isoMs(call.ended_at || call.completed_at, control.native_naive_timestamps_utc === true);
      if (!Number.isFinite(startedAt) || !Number.isFinite(completedAt) || startedAt < control.enrollment_at_ms || completedAt < startedAt || completedAt > now()) continue;
      if (candidates >= MAX_CANDIDATES_PER_POLL) break;
      const existing = await receipts.filter({ call_id: call.id }, '-created_date', 1);
      if (existing.length) {
        const prior = existing[0];
        if (reconciliations < 1 && ['dispatch_submitting', 'dispatch_unknown'].includes(prior.status)) {
          reconciliations++;
          if (await findVisibleMessage(fetchImpl, pat, prior.conversation_id, prior.message_id)) {
            await receipts.update(prior.id, { status: 'dispatch_accepted' });
          }
        }
        continue;
      }
      const detailResponse = await request(fetchImpl, `${BASE}/phone/calls/${call.id}`, runtimeToken);
      if (!detailResponse.ok) continue;
      const detail = await detailResponse.json();
      const transcript = detail?.transcript;
      if (detail?.call?.id !== call.id || detail.call.is_owner !== true || !['completed', 'failed'].includes(detail.call.status)) continue;
      if (!Array.isArray(transcript) || !hasOwnerSpeech(transcript, startedAt, completedAt, control.native_naive_timestamps_utc === true)) continue;
      candidates++;

      // Renew and fence before creating a durable dispatch receipt.
      const renewed = await controls.updateMany(
        { id: control.id, poll_request_id: requestId, poll_lock_until_ms: { $gt: now() } },
        { $set: { poll_lock_until_ms: now() + POLL_LOCK_MS } },
      );
      if (now() >= scanDeadline) return { enabled: true, processed, reason: 'scan_deadline' };
      if (!renewed?.success || renewed.updated !== 1) return { enabled: true, processed, reason: 'poll_lease_lost' };
      // Receipt first: a crash after this point must not turn into an automatic replay.
      const receipt = await receipts.create({ call_id: call.id, status: 'dispatch_pending', call_completed_at_ms: completedAt, created_at_ms: t });
      if (!receipt?.id) continue;
      let conversationId;
      try {
        const beforeDispatch = await controls.updateMany(
          { id: control.id, poll_request_id: requestId, poll_lock_until_ms: { $gt: now() } },
          { $set: { poll_lock_until_ms: now() + POLL_LOCK_MS } },
        );
        if (!beforeDispatch?.success || beforeDispatch.updated !== 1) {
          await receipts.update(receipt.id, { status: 'dispatch_deferred', error: 'poll_lease_lost' });
          return { enabled: true, processed, reason: 'poll_lease_lost' };
        }
        // Native owner messaging is authenticated with the server-only scoped PAT, as in callMe.
        // The short-lived runtime token is intentionally limited to phone read endpoints.
        const conversation = await request(fetchImpl, `${BASE}/user-agent/conversations/v2`, pat, { method: 'POST', body: JSON.stringify({ metadata: { source: 'after_call_bridge', call_id: call.id } }) });
        if (!conversation.ok) {
          await receipts.update(receipt.id, { status: 'dispatch_failed', error: 'conversation_create_failed' });
          continue;
        }
        const conversationData = await conversation.json();
        conversationId = conversationData?.id;
        if (typeof conversationId !== 'string' || !ID.test(conversationId)) throw new Error('invalid_conversation_id');
        const messageId = crypto.randomUUID();
        await receipts.update(receipt.id, { status: 'dispatch_submitting', conversation_id: conversationId, message_id: messageId });
        const delivery = await postWithDeliveryConfirmation(fetchImpl, `${BASE}/user-agent/conversations/${conversationId}/messages`, pat, {
          id: messageId, role: 'user', hidden: false, content: TRANSCRIPT_PROMPT.replace('{{CALL_ID}}', call.id).replace('{{CALL_STATUS}}', detail.call.status),
        }, conversationId, messageId);
        if (delivery.kind === 'unknown') {
          await receipts.update(receipt.id, { status: 'dispatch_unknown', lock_until_ms: now() + UNKNOWN_HOLD_MS });
          continue;
        }
        if (delivery.kind === 'rejected') {
          await receipts.update(receipt.id, { status: 'dispatch_failed', error: 'message_rejected' });
          continue;
        }
        await receipts.update(receipt.id, { status: 'dispatch_accepted' });
        processed++;
      } catch {
        // Never retry an ambiguous message submission automatically.
        await receipts.update(receipt.id, { status: 'dispatch_unknown', lock_until_ms: now() + UNKNOWN_HOLD_MS });
      }
    }
    return { enabled: true, processed, reason: 'ok' };
  } finally {
    await controls.updateMany({ id: control.id, poll_request_id: requestId }, { $set: { poll_lock_until_ms: 0 } });
  }
}

/** Admin-session-only until Base44 automation caller auth is proven. Never trusts a header. */
export async function handleAfterCallPoll(req, { createClientFromRequest, secrets, fetchImpl = fetch }) {
  if (req.method !== 'POST') return responseJson({ ok: false, error: 'method_not_allowed' }, 405);
  let base44, user;
  try { base44 = createClientFromRequest(req); user = await base44.auth.me(); } catch { return responseJson({ ok: false, error: 'unauthorized' }, 401); }
  if (!user) return responseJson({ ok: false, error: 'unauthorized' }, 401);
  if (user.role !== 'admin') return responseJson({ ok: false, error: 'forbidden' }, 403);
  const pat = secrets.get('JARVIS_NATIVE_TOKEN');
  const result = await runAfterCallPoll({ store: { control: base44.asServiceRole.entities.CallControl, receipt: base44.asServiceRole.entities.CallReceipt }, fetchImpl, pat });
  return responseJson(result);
}

