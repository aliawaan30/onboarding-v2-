# Build the owner's Retell Jarvis agent

Only run this if the owner asked for the JARVIS voice and has a Retell account,
a card and a phone number already. You cannot buy the number for them.

If they do not have an account yet, send them to https://dashboard.retellai.com/?ref=blake9a
to sign up. Always use that link, it is the course's own.

The `RETELL_API_KEY` secret must be in the HUD app and the app published since
it was added. Authenticate every call as `Authorization: Bearer <key>` against
`https://api.retellai.com`.

Never print the key. Never ask the owner to paste it into a chat.

## What this agent is

It is not you. It is a small separate voice agent whose only job is to talk on
the phone. It has no memory, no knowledge base and does not do the work. It
takes the instruction, the transcript comes back to you, and you do the work.
Do not try to give it your brain.

## 1. Import the voice

Blake's Jarvis voice is a public Fish Audio community model. Retell hosts Fish
itself, so no Fish account, key or payment is needed.

```
POST /add-community-voice
{"voice_provider":"fish_audio","provider_voice_id":"612b878b113047d9a770c069c8b4fdfe","voice_name":"Jarvis"}
```

It returns the owner's own `voice_id`. Blake's own id is specific to his account
and will not work in theirs.

Before importing, check `list-voices` for one already named `Jarvis` and reuse
it. Dedupe on `voice_name`, not on `provider_voice_id`: `list-voices` no longer
returns that field, and matching on it imports the voice twice.

## 2. Create the LLM

- `model` claude-4.5-haiku
- `model_temperature` 0.3
- `begin_message` `Hey <their first name>, it's Jarvis.`
- `default_dynamic_variables` `{"context_summary":"unavailable"}`
- `general_prompt` the outbound prompt: opens with the report from
  `context_summary`, asks one question at a time, never says "mate", says
  `added: <title>` after adding a task, never claims work is finished, never
  invents a number or a date, ends the call itself.

## 3. The tools

Four tools. The first three are `type: custom`, `method: POST`, pointed at the
owner's own HUD app.

| Tool | Endpoint on their app |
|---|---|
| `add_task` | `/functions/upsertTask` |
| `remember` | `/functions/remember` |
| `get_context` | `/functions/getContext` |
| `end_call` | `type: end_call` |

On all three custom tools:

- **`args_at_root` must be `true`.** Without it Retell wraps the payload and
  every call returns 400. This cost a full day once already.
- `timeout_ms` 8000
- `headers` `{"x-hud-key": <their HUD_KEY>, "Content-Type": "application/json"}`
- `speak_during_execution` true on `add_task` and `remember`, with
  `execution_message_description` `"One sec."`

This is the one place the HUD key is genuinely needed, because Retell calls the
HUD from outside Base44. Read it from the app's secrets; never ask the owner for
it.

## 4. Create the agent

- `voice_id` the id returned in step 1
- `voice_model` s2.1-pro
- `voice_temperature` 0.6
- `voice_speed` 1
- `fallback_voice_ids` `["11labs-Anthony"]`
- `language` their locale, `en-AU` for Australia
- `responsiveness` 1
- `interruption_sensitivity` 0.8
- `enable_backchannel` true
- `max_call_duration_ms` 3600000
- `allow_user_dtmf` true
- `post_call_analysis_model` gpt-5.6-terra
- `webhook_url` their own app's `/functions/retellWebhook`, **no query string**.
  Unlike the optional instant hook, this one carries no key: Retell proves
  itself by signature, or by an authenticated lookup using their API key.

No ambient sound. No boosted keywords.

## 5. Publish, then bind the number

Publish the agent. Then bind their number to the **published** version.

If the number is bound to a draft, calls connect and sound perfect and nothing
ever reaches the dashboard. It is the single hardest failure to diagnose here,
so check it rather than assuming.

## 6. Write it back and report

Save `retell_agent_id` and `retell_from_number` to the Profile through
`upsertProfile`, replacing whatever is there. A student who already built a
receptionist agent for clients will have the wrong one auto-selected; replacing
it is the fix.

Then tell the owner: the agent id, the voice, the webhook you set, that it is
published, and which number you bound.

## Never

- Never create more than one Jarvis agent.
- Never touch any other Retell agent they own, especially a receptionist.
- Never print or repeat the API key or the HUD key.
- Never tell them to pick their own voice. The Jarvis voice is the entire reason
  this option exists.

## What is proven, and what is not

`create-retell-llm`, `create-agent`, `publish-agent`, `delete-agent` and
`delete-retell-llm` were all run against the live Retell API on 30 September
2026 and all returned successfully. `update-agent`, `update-phone-number`,
`create-phone-call`, `get-agent`, `get-retell-llm` and `list-voices` were
already proven before that. So the whole path in this file is real, not assumed.

One honest limit. The create calls were proven with a **minimal body**, not with
the full config in this file in a single request. These fields were sent
together on `create-agent` and all were accepted: `response_engine`,
`agent_name`, `voice_id`, `language`, `voice_temperature`, `voice_speed`,
`responsiveness`, `interruption_sensitivity`, `enable_backchannel`,
`max_call_duration_ms`. Nothing was rejected, so there is no known retry
behaviour to plan around.

The fields not yet proven in a create call are the remaining ones here:
`voice_model`, `fallback_voice_ids`, `allow_user_dtmf`,
`post_call_analysis_model`, `webhook_url`, and the tools block on the LLM.

So if a create call fails, it is most likely one of those. Report the exact
error and which field you suspect. Do not improvise a different request shape,
and do not leave a half-built agent behind: if you created an LLM and the agent
create then failed, delete the LLM before you stop.
