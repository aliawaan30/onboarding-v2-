# The install prompt

Give this to the owner exactly as written, to paste into the **Jarvis HUD app's
own builder chat** with the package zip attached in the same message. Do not
paraphrase it and do not shorten it.

The copy order is not decoration. Writing a file before the thing it imports
makes the dev server cache a file-not-found that never clears, and the student
gets a blank screen that looks like a failed install.

```text
Install the attached Jarvis dashboard package into this app as the exact source of truth. Unzip it and copy every file under source/ into this project at the same paths, replacing what is there.

Copy in this order, because a file that is imported must exist before the file that imports it: first everything under base44/, then src/api/, src/lib/, src/hooks/, src/utils/, then src/components/ (all of it, including src/components/jarvis/), then src/pages/, then src/index.css, and only last src/App.jsx, src/main.jsx and index.html. After every file is copied, restart or reload the dev server before building, so it cannot keep a cached file-not-found result from before the copy.

Never rename a file, never move a file to a different path, and never change an import path to work around a "Failed to resolve import" error. If you hit one: list the file it cannot find and prove whether it exists at that exact path; if it exists, the resolve result is stale, so re-write that file and its importer in place with identical content and build again. Renaming forks this app from the package and breaks every future update.

Keep the app's login requirement on. Do not redesign, simplify, rename or recreate any page, component, style, entity, backend function, shared module or workflow; use the files exactly as supplied. Keep secrets empty; I will add them myself in Dashboard, then Secrets. After copying, run the build and fix only genuine build errors caused by missing dependencies in package.json, nothing else. Then list every file you wrote and confirm the build passes. Do not publish; I will.
```

## Package

https://theaiagencyai.netlify.app/jarvis-hud-live.zip

Attach the file itself. A link in the builder chat is not the same thing; the
builder needs the attachment.
