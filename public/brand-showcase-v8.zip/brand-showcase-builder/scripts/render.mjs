#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { page, brands } from '../src/pages.mjs';
import { mountShowcase } from '../src/runtime.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const version = '8.0.0';
const escape = value => value.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const mime = {'.jpg':'image/jpeg','.svg':'image/svg+xml','.ttf':'font/ttf'};
function verify() {
  const list = JSON.parse(fs.readFileSync(path.join(root,'checksums.json'),'utf8'));
  for (const [file, expected] of Object.entries(list)) {
    if (file.includes('..') || path.isAbsolute(file)) throw Error('Invalid package path.');
    const hash = crypto.createHash('sha256').update(fs.readFileSync(path.join(root,file))).digest('hex');
    if (hash !== expected) throw Error(`Package file changed or damaged: ${file}. Attach a fresh v8 bundle.`);
  }
}
function run() {
  const args = process.argv.slice(2); const opts = {};
  for (let i=0; i<args.length; i++) {
    if (args[i] === '--verify') { opts.verify = true; continue; }
    if (!['--brand','--student','--out','--asset-map'].includes(args[i]) || !args[i+1] || args[i+1].startsWith('--')) throw Error('Use --brand nike|apple|ikea|mcd --student NAME --out DIRECTORY [--asset-map FILE], or --verify.');
    opts[args[i].slice(2)] = args[++i];
  }
  verify();
  if (opts.verify && !opts.brand) { console.log(JSON.stringify({verified:true,version})); return; }
  const alias = String(opts.brand || '').toLowerCase().replace(/[’']/g,'').replace(/[^a-z]/g,'');
  const brand = alias === 'mcdonalds' ? 'mcd' : alias;
  if (!Object.hasOwn(brands,brand)) throw Error('This onboarding build supports Nike, Apple, IKEA and McDonald\'s. Choose one of those four.');
  if (!opts.out) throw Error('An output directory is required.');
  const student = escape(String(opts.student || 'Your studio').replace(/[\u0000-\u001f\u007f]/g,'').replace(/\u2014/g,', ').trim().slice(0,80) || 'Your studio');
  const out = path.resolve(opts.out); fs.mkdirSync(out,{recursive:true});
  const used = new Set();
  const inline = file => {
    used.add(file);
    const type = mime[path.extname(file)]; if (!type || path.basename(file) !== file) throw Error('Invalid asset.');
    return `data:${type};base64,${fs.readFileSync(path.join(root,'assets',file)).toString('base64')}`;
  };
  const css = fs.readFileSync(path.join(root,'src/style.css'),'utf8');
  const font = asset => brands[brand].font ? `@font-face{font-family:Showcase${brand==='nike'?'Anton':'Archivo'};src:url("${asset(brands[brand].font+'-font.ttf')}") format("truetype");font-style:normal;font-weight:400;font-display:swap}` : '';
  const body = asset => `${page(brand,asset,student)}<div class="bs-status" role="status" aria-live="polite" aria-atomic="true"></div>`;
  const htmlBody = body(inline); const htmlCss = font(inline)+css;
  const title = escape(brands[brand].name+' | Independent concept');
  const html = `<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta name="color-scheme" content="light"><title>${title}</title><style>html,body{margin:0;padding:0}body{background:#fff}${htmlCss}</style></head><body><div class="bs bs-${brand}" data-showcase-version="${version}">${htmlBody}</div><script>(${mountShowcase.toString()})(document.querySelector('.bs'));</script></body></html>`;
  fs.writeFileSync(path.join(out,'index.html'),html);
  let mapping = {};
  if (opts['asset-map']) mapping = JSON.parse(fs.readFileSync(opts['asset-map'],'utf8'));
  const nativeAsset = file => {
    if (!opts['asset-map']) return `/showcase-assets/${file}`;
    const value = mapping[file];
    if (typeof value !== 'string' || new URL(value).protocol !== 'https:') throw Error(`Missing public HTTPS asset URL for ${file}.`);
    return value;
  };
  const nativeBody = body(file => escape(nativeAsset(file))); const nativeCss = font(file => nativeAsset(file).replace(/["<>\\]/g, c => encodeURIComponent(c)))+css;
  // JSON string literals prevent student text, including </script>, becoming code.
  const jsx = `import { useEffect, useRef } from 'react';\nconst markup = ${JSON.stringify(nativeBody)};\nconst css = ${JSON.stringify(nativeCss)};\nconst mountShowcase = ${mountShowcase.toString()};\nexport default function Showcase() {\n  const root = useRef(null);\n  useEffect(() => mountShowcase(root.current), []);\n  return <><style>{css}</style><div ref={root} className="bs bs-${brand}" data-showcase-version="${version}" dangerouslySetInnerHTML={{__html: markup}} /></>;\n}\n`;
  fs.writeFileSync(path.join(out,'Showcase.jsx'),jsx);
  const files = [...used].sort();
  if (!opts['asset-map']) {
    fs.mkdirSync(path.join(out,'public/showcase-assets'),{recursive:true});
    for (const file of files) fs.copyFileSync(path.join(root,'assets',file),path.join(out,'public/showcase-assets',file));
  }
  fs.writeFileSync(path.join(out,'upload-manifest.json'),JSON.stringify(files.map(file=>({file,path:path.join(root,'assets',file)})),null,2)+'\n');
  const info = {version,brand:brands[brand].name,brief:brands[brand].brief,source:brands[brand].source,assets:files,standaloneBytes:Buffer.byteLength(html),nativeComponentBytes:Buffer.byteLength(jsx),nativeAssets:opts['asset-map']?'public-upload-urls':'copy public/showcase-assets into the frontend public directory',output:out};
  fs.writeFileSync(path.join(out,'build-report.json'),JSON.stringify(info,null,2)+'\n');
  console.log(JSON.stringify(info,null,2));
}
try { run(); } catch(error) { console.error(`Showcase: ${error.message}`); process.exitCode=1; }
