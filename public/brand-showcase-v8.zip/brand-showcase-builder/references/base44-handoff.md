# Base44 frontend handoff

The sandbox and app builder are separate environments. A path in `/app` is not automatically a file inside the app. Transfer the actual component and assets using the tool capabilities available to you. Do not merely mention a sandbox path and assume it was imported.

## Preferred: copy files into the app frontend

If the app tools accept file attachments or exact file contents, provide generated `Showcase.jsx` and `public/showcase-assets/`. Mount `<Showcase />` as the full-width demo page with no platform starter navigation, global padding or default max-width. Preserve existing React dependencies. This component has its own scoped CSS and runtime; no Tailwind, animation library or extra dependency is required. Ensure the app body has zero margin.

## Alternative: upload media, then pass the small component

If the app tool accepts instructions but cannot copy the local assets:

1. Read `upload-manifest.json`. Use Base44 `upload_file` for each listed asset, retaining the returned public HTTPS URL. These are the only media files needed. Do not upload the entire archive or embed megabytes of base64 into the app-builder instruction.
2. Write a JSON object mapping the exact asset filename to its URL, for example `{"nike-night.jpg":"https://...", "nike-race.jpg":"https://...", "nike-logo.svg":"https://...", "anton-font.ttf":"https://..."}`. The real map must include every file in the manifest. Never use example URLs.
3. Rerun the same renderer with `--asset-map /app/showcases/nike/asset-map.json`. It produces `Showcase.jsx` with the supplied media URLs. `index.html` still embeds its own media as an independent fallback.
4. Send the actual contents of `Showcase.jsx` to the app builder in one instruction, or use a tool-supported file attachment that the builder can read. It is about 30 KB, not the large standalone HTML. If a tool reports an instruction-size limit, use its file transfer feature; do not truncate the component.

If the upload tool cannot accept a font or SVG, use the preferred file-copy path. Do not claim that a JPG upload proves fonts and SVGs are supported. An unsupported handoff is a failed platform check, not permission to redraw the logo.

## Builder instruction

Provide the following instruction with the actual generated component and the selected asset-transfer method:

"Create this exact standalone showcase as a native Base44 frontend page. Use the supplied Showcase.jsx verbatim as the page component, mounting it full width with zero outer body margin. Keep its embedded scoped CSS and useEffect runtime. [Copy the supplied public/showcase-assets files to the same frontend public path / The component already contains the uploaded asset URLs.] Do not redesign it, substitute media, add sections, write forms or use a backend function to serve HTML. Remove only starter shell padding or navigation that prevents this page from occupying the viewport. Set the document title to [brand] | Independent concept and add noindex,nofollow. Return the app preview URL and report whether the source and assets were installed successfully."

Replace bracketed instructions with the real choice. Ask for changes only within this new demo app or its dedicated demo page. If no native app creation tool is available, return the standalone download, say what is unavailable, and stop the publishing step.

## Acceptance evidence

Use the browser on the resulting frontend URL. Check the exact heading, every visible image, and a real content-changing interaction. If the app builder only returns a textual claim, treat it as unverified. The package's local React test does not validate Base44 upload support, builder instruction fidelity, credit usage or its chat preview behaviour.

Do not make a public portfolio, index the concept or attach a client domain as part of onboarding. Preserve the visible concept/non-affiliation footer and source link. Source materials have third-party rights; a non-affiliation label is not a licence.
