# Artwork and copy register

Prepared 7 September 2026 for a local course concept evaluation. These designs are a reference snapshot, not live catalogues. Artwork is supplied to make this test repeatable. No image-generation claim, model benchmark or brand approval is implied.

## Nike

Source: https://about.nike.com/en-GB/newsroom/releases/the-after-dark-tour-is-back-a-global-race-series-built-for-women-powered-by-nike

`nike-night.jpg` and `nike-race.jpg` are Nike's After Dark Tour campaign photographs, downloaded from that article's linked Nike media CDN. Their red treatment is part of the source artwork. They are not generated, recoloured or presented as photographs of a student's event. The visible campaign text on race clothing is in the supplied source. Headlines on this concept page are original illustrative copy, not attributed Nike slogans.

## Apple

Source: https://www.apple.com/newsroom/2025/09/apple-unveils-iphone-17-pro-and-iphone-17-pro-max/

`apple-hero.jpg`, `apple-camera.jpg`, `apple-colours.jpg`: actual Apple product photography linked from the announcement. The design identifies iPhone 17 Pro and the source's named finishes, deep blue, cosmic orange and silver. It makes no price, performance, battery, availability or newest-model claim.

## IKEA

Room source: https://www.ikea.com/au/en/rooms/living-room/gallery/sun-surf-and-smart-storage-pubc05e9420/

`ikea-room.jpg` and `ikea-detail.jpg`: official room and detail photographs. Hotspots discuss visible colour, texture and storage. They do not pretend to identify an unverified SKU or put a made-up price on the room.

`ikea-table.jpg`: IKEA image `gladom-tray-table-white__0470732_pe612912_s5.jpg`. It is a separate GLADOM tray table feature, not a claim that GLADOM is the table shown in the room. The outbound search link lets the viewer check the official catalogue.

`ikea-logo.svg`: https://www.ikea.com/global/assets/logos/brand/ikea.svg

## McDonald's

Source: https://www.mcdonalds.com/us/en-us/product/big-mac.html

`mcd-burger.jpg`: official product photo from the linked McDonald's Scene7 CDN, `Header_BigMac_832x472:product-header-desktop`. The ingredient descriptions refer to that US product. The footer and outbound CTA identify the US source. No local availability, price, nutrition, dietary or ordering claim is made. No generated packaging is substituted for a real product. The concept uses the golden arches and the real food photograph; it does not claim to show branded packaging that is absent from the source image.

## Marks and type

Nike, Apple and McDonald's SVG marks were retrieved from https://cdn.simpleicons.org/nike, https://cdn.simpleicons.org/apple and https://cdn.simpleicons.org/mcdonalds. These are third-party vector transcriptions from Simple Icons, not SVGs fetched directly from a brand header. Brand trademarks still belong to their owners. IKEA's mark is from IKEA directly.

Anton and Archivo Black are supplied from the Google Fonts repository with their original OFL licence files. They are chosen display typefaces, not claims to be the brands' proprietary fonts. Apple uses system type; IKEA uses Arial/Helvetica fallbacks.

Original image dimensions were reduced and JPEGs compressed for local delivery. Website crops are CSS object-fit framing. Product shape and colours were not generated or edited. The package includes only the assets each renderer uses.

## Distribution boundary

Brand photos and trademarks remain third-party materials. This register documents provenance; it grants no reproduction or redistribution licence. Private viewing and a non-affiliation footer do not automatically clear rights. The pack is prepared for Blake's local evaluation. Before distributing this exact media pack to a course cohort or publishing copies, establish an appropriate permission basis or replace media with assets licensed for that distribution. Keep provenance when replacing assets and re-run the visual checks. The engine and source code can be reused with client-supplied or licensed media.
