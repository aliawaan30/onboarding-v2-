// The same runtime mounts in standalone HTML and the Base44 React frontend.
// No inline event handlers, network calls, storage, forms or global CSS.
export function mountShowcase(root) {
  const q = s => root.querySelector(s);
  const all = s => Array.from(root.querySelectorAll(s));
  const menu = q('.bs-menu-button');
  const nav = q('.bs-nav');
  function closeMenu(focus = false) {
    menu.setAttribute('aria-expanded', 'false');
    nav.classList.remove('is-open');
    if (focus) menu.focus();
  }
  function onClick(event) {
    const target = event.target.closest('button,a');
    if (!target || !root.contains(target)) return;
    if (target === menu) {
      const open = menu.getAttribute('aria-expanded') !== 'true';
      menu.setAttribute('aria-expanded', String(open));
      nav.classList.toggle('is-open', open);
    }
    if (target.matches('.bs-nav a')) closeMenu();
    if (target.dataset.view) {
      const group = target.dataset.group;
      const view = target.dataset.view;
      all('[data-group]').filter(el => el.dataset.group === group).forEach(el => {
        if (el.matches('button')) el.setAttribute('aria-pressed', String(el.dataset.view === view));
        else if (el.hasAttribute('data-panel')) el.hidden = el.dataset.panel !== view;
      });
      const panel = all('[data-panel]').find(el => el.dataset.group === group && !el.hidden);
      const status = q('.bs-status');
      if (status) status.textContent = panel?.querySelector('h2,figcaption')?.textContent || '';
    }
  }
  function onKey(event) {
    if (event.key === 'Escape' && menu.getAttribute('aria-expanded') === 'true') closeMenu(true);
  }
  root.addEventListener('click', onClick);
  root.addEventListener('keydown', onKey);
  root.classList.add('bs-ready');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  let observer;
  if (!reduced.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('bs-arrived'); observer.unobserve(entry.target); }
    }), { threshold: 0.08 });
    all('.bs-section-heading, .ik-detail-copy, .mc-layers > div, .ap-product-caption').forEach(el => observer.observe(el));
  }
  return () => {
    observer?.disconnect();
    root.removeEventListener('click', onClick);
    root.removeEventListener('keydown', onKey);
    root.classList.remove('bs-ready');
  };
}
